from flask import Flask, request, jsonify, render_template
import sqlite3

app = Flask(__name__)

# 🔹 Connexion à la base
def get_db():
    conn = sqlite3.connect("database.db")
    return conn

# 🔹 Création automatique de la base
def init_db():
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS resultats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        x1 REAL,
        x2 REAL,
        P REAL,
        y1 REAL,
        y2 REAL
    )
    """)

    conn.commit()
    conn.close()

# 🔥 IMPORTANT : lancer la création
init_db()

# 🔹 Page principale
@app.route('/')
def home():
    return render_template("index.html")

# 🔹 Calcul + stockage
@app.route('/calcul', methods=['POST'])
def calcul():

    data = request.json

    x1 = data['x1']
    x2 = data['x2']

    # 🔥 Vérification
    if round(x1 + x2, 2) != 1:
        return jsonify({"error": "x1 + x2 doit être = 1"})

    # 🔹 Données déjà connues
    P1 = 101.3  # benzène
    P2 = 40     # toluène

    # 🔹 Calcul
    P = x1 * P1 + x2 * P2
    y1 = (x1 * P1) / P
    y2 = (x2 * P2) / P

    # 🔹 Sauvegarde dans DB
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
    INSERT INTO resultats (x1, x2, P, y1, y2)
    VALUES (?, ?, ?, ?, ?)
    """, (x1, x2, P, y1, y2))

    conn.commit()
    conn.close()

    return jsonify({
        "Pression_bulle": round(P, 2),
        "y1": round(y1, 3),
        "y2": round(y2, 3),
        "Somme": round(y1 + y2, 3)
    })

# 🔹 Voir tous les résultats stockés
@app.route('/historique')
def historique():

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM resultats")
    rows = cursor.fetchall()

    conn.close()

    return jsonify(rows)

# 🔹 Lancer app
if __name__ == '__main__':
    app.run(debug=True)